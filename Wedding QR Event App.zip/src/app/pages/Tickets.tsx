import { useState, useEffect, useLayoutEffect } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Ticket } from 'lucide-react';

export default function Tickets() {
  const navigate = useNavigate();
  const [ticketNumbers, setTicketNumbers] = useState<number[]>([]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('missionProgress');
    if (saved) {
      const data = JSON.parse(saved);
      // Retrieve or generate numbers based on completed tickets
      const completedCount = data.tickets || 0;
      let numbers = data.ticketNumbers || [];

      // If we have tickets but no generated numbers, generate them once
      if (numbers.length < completedCount) {
        const newNumbers = [...numbers];
        for (let i = numbers.length; i < completedCount; i++) {
          newNumbers.push(Math.floor(Math.random() * 90) + 10); // Random 2 digit number
        }
        numbers = newNumbers;

        // Save back to localStorage
        const newData = { ...data, ticketNumbers: numbers };
        localStorage.setItem('missionProgress', JSON.stringify(newData));
      }

      setTicketNumbers(numbers);
    }
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white sticky top-0 z-10 pt-4 pb-2">
        <div className="max-w-md mx-auto px-6">
          <button
            onClick={() => navigate('/')}
            className="p-2 -ml-2 hover:bg-gray-100 rounded-full transition-colors flex w-fit"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700" />
          </button>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 mb-6 mt-4">
        <div className="flex-1 pb-2 text-center">
          <h1 className="text-[26px] font-bold text-[#000000] mb-2">당신의 추첨 번호는...</h1>
          <p className="font-medium text-lg text-gray-500 leading-relaxed whitespace-pre-line text-center">
            미션 완료를 통해 획득한 번호입니다
          </p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-2 text-center">
        {ticketNumbers.length === 0 ? (
          <div className="py-12 bg-gray-50 rounded-2xl border-[0.75px] border-gray-200">
            <Ticket className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">아직 획득한 추첨권이 없습니다.</p>
            <p className="text-sm text-gray-400 mt-1">미션을 완료하고 번호를 받아보세요!</p>
          </div>
        ) : (
          <div className="flex flex-wrap justify-center gap-6">
            {ticketNumbers.map((num, idx) => (
              <div
                key={idx}
                className="w-32 h-32 flex flex-col items-center justify-center p-4 relative overflow-hidden transform hover:scale-105 active:scale-95 transition-transform shrink-0"
              >
                <img src="/ball.png" alt="추첨권" className="absolute w-24 h-24 object-contain opacity-30" />
                <span className="text-3xl font-bold text-[#E83E7A] z-10 mb-1">{num}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
