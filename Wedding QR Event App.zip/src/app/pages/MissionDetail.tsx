import { useState, useEffect, useLayoutEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router';
import { ArrowLeft, Upload, Camera, QrCode, HelpCircle, Check, Award } from 'lucide-react';
import QRCode from 'react-qr-code';
import { Scanner } from '@yudiel/react-qr-scanner';
import Lottie from 'lottie-react';
import photoAnimation from '../../assets/photo-animation.json';
import heartAnimation from '../../assets/heart-animation.json';
import treasureAnimation from '../../assets/treasure-animation.json';
import foodAnimation from '../../assets/food-animation.json';
import { MISSIONS } from '../types/mission';
import { supabase } from '../../lib/supabase';
import { secretWordList } from '../../assets/secretWords';

export default function MissionDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const missionId = parseInt(id || '0');
  const mission = MISSIONS.find(m => m.id === missionId);

  const [completedMissions, setCompletedMissions] = useState<number[]>([]);
  const [tickets, setTickets] = useState(0);
  const [missionImages, setMissionImages] = useState<Record<number, string>>({});
  const [showHint, setShowHint] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedQuiz, setSelectedQuiz] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [showQrScanner, setShowQrScanner] = useState(false);
  const [secretWord, setSecretWord] = useState('');

  useEffect(() => {
    setTimeout(() => {
      // window.scrollTo(0, 0);
      // alert("움직여")
    }, 300)
  }, []);



  useEffect(() => {
    const saved = localStorage.getItem('missionProgress');
    if (saved) {
      const data = JSON.parse(saved);
      setCompletedMissions(data.completedMissions || []);
      setTickets(data.tickets || 0);
      setSecretWord(data.secretWord || '');
      setMissionImages(data.missionImages || {});

      if (data.missionImages && data.missionImages[missionId]) {
        setUploadedImage(data.missionImages[missionId]);
      }
    }
  }, [missionId]);

  if (!mission) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">미션을 찾을 수 없습니다.</p>
          <button
            onClick={() => navigate(-1)}
            className="mt-4 text-purple-600 font-medium"
          >
            홈으로 돌아가기
          </button>
        </div>
      </div>
    );
  }

  const isCompleted = completedMissions.includes(missionId);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);

    const reader = new FileReader();
    reader.onloadend = () => {
      setUploadedImage(reader.result as string);
    };
    reader.readAsDataURL(file);

    try {
      const fileExt = file.name.split('.').pop() || 'jpg';
      const fileName = `mission_${missionId}_${Date.now()}.${fileExt}`;
      const filePath = `user_uploads/${fileName}`;

      const { data, error } = await supabase.storage
        .from('images')
        .upload(filePath, file);

      if (error) {
        throw error;
      }

      const { data: publicUrlData } = supabase.storage
        .from('images')
        .getPublicUrl(filePath);

      setUploadedImage(publicUrlData.publicUrl);
    } catch (err) {
      console.error('업로드 실패. 로컬 프리뷰로 유지합니다.', err);
    } finally {
      setIsUploading(false);
    }
  };

  const completeMission = () => {
    if (!isCompleted) {
      const newCompletedMissions = [...completedMissions, missionId];
      const newTickets = tickets + 1;
      const newMissionImages = { ...missionImages };

      if (uploadedImage) {
        newMissionImages[missionId] = uploadedImage;
      }

      const data = {
        completedMissions: newCompletedMissions,
        tickets: newTickets,
        secretWord,
        missionImages: newMissionImages
      };

      localStorage.setItem('missionProgress', JSON.stringify(data));
      setCompletedMissions(newCompletedMissions);
      setTickets(newTickets);
      setMissionImages(newMissionImages);

      setTimeout(() => {
        navigate('/');
      }, 2000);
    }
  };

  const handleQuizSubmit = () => {
    setQuizSubmitted(true);
    if (selectedQuiz === mission.quizAnswer) {
      setTimeout(() => {
        completeMission();
      }, 1500);
    }
  };

  const handleQrScan = () => {
    // Simulate QR scan
    // return
    setShowQrScanner(false);
    completeMission();
  };
  const scrollRef = useRef<HTMLDivElement>(null)

  return (
    <div className="min-h-screen bg-white relative" ref={scrollRef}>
      {/* Header - Sticky Back Button Only */}
      <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm pt-4 pb-4">
        <div className="max-w-md mx-auto px-6">
          <button
            onClick={() => {
              // scrollRef.current?.scrollTo(0, 0)
              navigate(-1)
            }}
            className="p-2 -ml-2 hover:bg-gray-100 rounded-full transition-colors flex w-fit"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700" />
          </button>
        </div>
      </div>

      {/* Static Title Area */}
      <div className="pt-2 pb-2">
        <div className="max-w-md mx-auto px-6">
          <div className="text-center">
            <h1 className="text-[26px] font-bold text-[#000000] mb-2">{mission.title}</h1>
            <p className="font-medium text-lg text-gray-500 leading-relaxed whitespace-pre-line">{mission.description}</p>

            {!isCompleted && !uploadedImage && mission.id === 1 && (
              <div className="w-full flex justify-center mt-[64px] mb-2">
                <div className="w-48 h-48">
                  <Lottie animationData={photoAnimation} loop={true} />
                </div>
              </div>
            )}
            {!isCompleted && !uploadedImage && mission.id === 2 && (
              <div className="w-full flex justify-center mt-2 mb-2">
                <div className="w-80 h-80">
                  <Lottie animationData={heartAnimation} loop={true} />
                </div>
              </div>
            )}
            {!isCompleted && !uploadedImage && mission.id === 3 && (
              <div className="w-full flex justify-center mt-[40px] mb-2 ">
                <div className="w-48 h-48">
                  <Lottie animationData={treasureAnimation} loop={true} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6">
        {/* Mission Card */}
        <div className="bg-white rounded-[20px] p-6 mb-6">
          {isCompleted && (
            <div className="mb-12 bg-green-50 border-1 border-green-300 rounded-xl p-4 text-center">
              <div className="text-green-700">
                <p className="font-bold">미션 완료!</p>
                <p className="text-sm mt-1">추첨권 1매를 획득했습니다 🎉</p>
              </div>
            </div>
          )}
          {isCompleted && missionId === 5 && (
            <div className="text-center mb-2">
              <h2 className="text-xl font-bold text-gray-800 mb-2 mt-2">웨딩 코스 요리 메뉴</h2>
              <p className="text-gray-600 mb-6 font-medium text-sm">오늘 제공될 점심 식사 메뉴입니다</p>

              <div className="bg-gradient-to-br from-[#FFF0F5] to-white rounded-[16px] p-6 text-gray-800 space-y-7 font-medium border border-[#FFE2EA] shadow-inner">
                <div className="flex flex-col items-center gap-1.5"><span className="text-3xl mb-1">🥖</span> <div className="text-center"><p className="text-[15px] font-bold">식전 빵</p><p className="text-xs text-gray-500 mt-0.5 font-normal">Fresh Baked Bread</p></div></div>
                <div className="flex flex-col items-center gap-1.5"><span className="text-3xl mb-1">🥗</span> <div className="text-center"><p className="text-[15px] font-bold">훈제 연어 샐러드</p><p className="text-xs text-gray-500 mt-0.5 font-normal">Smoked Salmon Salad</p></div></div>
                <div className="flex flex-col items-center gap-1.5"><span className="text-3xl mb-1">🥣</span> <div className="text-center"><p className="text-[15px] font-bold">양송이 크림 수프</p><p className="text-xs text-gray-500 mt-0.5 font-normal">Mushroom Cream Soup</p></div></div>
                <div className="flex flex-col items-center gap-1.5"><span className="text-3xl mb-1">🥩</span> <div className="text-center"><p className="text-[15px] text-[#E93F6F] font-bold">안심 스테이크</p><p className="text-xs text-[#E93F6F]/80 mt-0.5 font-normal">Tenderloin Steak</p></div></div>
                <div className="flex flex-col items-center gap-1.5"><span className="text-3xl mb-1">🍰</span> <div className="text-center"><p className="text-[15px] font-bold">티라미수 케이크</p><p className="text-xs text-gray-500 mt-0.5 font-normal">Tiramisu Cake</p></div></div>
                <div className="flex flex-col items-center gap-1.5"><span className="text-3xl mb-1">☕</span> <div className="text-center"><p className="text-[15px] font-bold">커피 또는 홍차</p><p className="text-xs text-gray-500 mt-0.5 font-normal">Coffee or Tea</p></div></div>
              </div>
            </div>
          )}

          {/* Photo Upload Missions */}
          {mission.type === 'photo' && (
            <div className="space-y-4">
              {!isCompleted && !uploadedImage && mission.hint && (
                <div className="mb-4">
                  <button
                    onClick={() => setShowHint(!showHint)}
                    className="flex justify-center items-center gap-2 text-pink-600 font-medium hover:text-pink-700 w-full"
                  >
                    <HelpCircle className="w-5 h-5" />
                    {showHint ? '힌트 숨기기' : '힌트 보기'}
                  </button>
                  {showHint && (
                    <div className="mt-3 bg-pink-50 border-[0.75px] border-pink-200 rounded-xl p-4 mb-[80px]">
                      <p className="text-pink-800">{mission.hint}</p>
                    </div>
                  )}
                </div>
              )}

              {uploadedImage ? (
                <div className="space-y-4">
                  <img
                    src={uploadedImage}
                    alt="Uploaded"
                    className="w-full rounded-xl object-cover max-h-96"
                  />

                  <div className='h-12' />

                  {!isCompleted && (
                    <div className="fixed bottom-0 left-0 right-0 p-4 z-50 pointer-events-none" style={{ background: 'linear-gradient(to top, rgba(255,255,255,1) 60%, rgba(255,255,255,0.8) 80%, rgba(255,255,255,0) 100%)' }}>
                      <div className="max-w-md mx-auto flex gap-3 w-full  pointer-events-auto">
                        <button
                          onClick={() => setUploadedImage(null)}
                          className="flex-1 px-[16px] py-[16px] bg-[#ffffff] text-[#F73295] rounded-[16px] font-bold hover:bg-pink-50 active:scale-[0.98] transition-all border-[1px] border-[#FFD4EA]"
                        >
                          다시 촬영
                        </button>
                        <button
                          onClick={completeMission}
                          disabled={isUploading}
                          className="flex-[2] py-[16px] bg-[#F73295] text-white rounded-[16px] font-bold shadow-[0_4px_12px_rgba(247,50,149,0.3)] hover:-translate-y-1 active:scale-[0.98] transition-transform border-[0.75px] border-transparent disabled:opacity-50"
                        >
                          {isUploading ? '업로드 중...' : '미션 완료'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : !isCompleted ? (
                <div className="fixed bottom-0 left-0 right-0 p-4 z-50 pointer-events-none" style={{ background: 'linear-gradient(to top, rgba(255,255,255,1) 60%, rgba(255,255,255,0.8) 80%, rgba(255,255,255,0) 100%)' }}>
                  {/* <div className="fixed bottom-0 left-0 right-0 pt-24 pb-8 z-50 pointer-events-none" style={{ background: 'linear-gradient(to top, rgba(255,255,255,1) 60%, rgba(255,255,255,0.8) 80%, rgba(255,255,255,0) 100%)' }}> */}
                  <div className="max-w-md mx-auto w-full pointer-events-auto">
                    <label className="block w-full cursor-pointer">
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      <div className="w-full bg-[#F73295] text-white font-bold py-[16px] rounded-[16px] shadow-[0_4px_12px_rgba(247,50,149,0.3)] flex items-center justify-center gap-2 hover:-translate-y-1 active:scale-[0.98] transition-all cursor-pointer">
                        <Camera className="w-6 h-6" />
                        사진 촬영하기
                      </div>
                    </label>
                  </div>
                </div>
              ) : null}


            </div>
          )}

          {/* QR Mission */}
          {mission.type === 'qr' && !isCompleted && (
            <div className="space-y-4 ">
              <div className="bg-pink-50 border-[0.75px] border-pink-300 rounded-[20px] p-6 text-center mb-[48px]">
                <div className="flex flex-col items-center justify-center">
                  {/* <div className="text-4xl mb-3">🔐</div> */}
                  {/* <h3 className="font-semibold text-pink-900 mb-2">내 비밀의 단어</h3> */}
                  <p className="text-3xl font-bold text-pink-700 my-1">{secretWordList[0].title}</p>


                  <div className='mb-4 mt-1'>

                    {secretWordList[0].content.map((item, i) => {
                      return (
                        <p key={i} className="text-sm text-[#e9137e] mt-3  py-[3px] px-[6px] bg-[#F73295]/10 rounded-[8px]">
                          {item}
                        </p>
                      )
                    })}
                  </div>

                  <p className="text-sm text-pink-800 mt-2 mb-6">
                    이 단어를 직접 언급하지 말고, 다른 방식으로 설명하여 같은 단어를 가진 사람을 찾아보세요!
                  </p>

                  {secretWord ? (
                    <div className="bg-white p-4 rounded-xl shadow-sm border-[0.75px] border-pink-100 flex flex-col items-center">
                      <QRCode value={secretWord} size={150} fgColor="#831843" />
                      <p className="text-xs text-pink-500 font-medium mt-3">나의 고유 QR 코드</p>
                    </div>
                  ) : null}
                </div>
              </div>
              <div className='h-4' />

              {/* Live QR Scanner using yudiel/react-qr-scanner */}
              {showQrScanner ? (
                <div className="fixed inset-0 z-50 bg-black flex flex-col">
                  {/* Scanner overlay */}
                  <div className="flex-1 relative w-full h-full flex items-center justify-center">
                    <Scanner
                      onScan={(result) => {

                        if (result && result.length > 0) {
                          // alert(JSON.stringify(result, null, 2))
                          // result[0].rawValue
                          handleQrScan();
                        }
                      }}
                      onError={(error: any) => console.log('QR Scan Error:', error?.message)}
                      constraints={{ facingMode: 'environment' }}
                    />
                    <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center z-10 bg-gradient-to-b from-black/50 to-transparent">
                      <button onClick={() => setShowQrScanner(false)} className="bg-black/50 p-2 rounded-full text-white">
                        <ArrowLeft className="w-6 h-6" />
                      </button>
                      <p className="text-white font-medium">QR 코드를 스캔하세요</p>
                      <div className="w-10"></div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="fixed bottom-0 left-0 right-0 p-4 z-50 pointer-events-none" style={{ background: 'linear-gradient(to top, rgba(255,255,255,1) 60%, rgba(255,255,255,0.8) 80%, rgba(255,255,255,0) 100%)' }}>
                  <div className="max-w-md mx-auto  w-full pointer-events-auto">
                    <button
                      onClick={() => setShowQrScanner(true)}
                      className="w-full bg-[#F73295] text-white font-bold py-[16px] rounded-[16px] shadow-[0_4px_12px_rgba(247,50,149,0.3)] flex items-center justify-center gap-2 hover:-translate-y-1 active:scale-[0.98] transition-transform border-[0.75px] border-transparent"
                    >
                      <QrCode className="w-5 h-5" />
                      상대방 qr 인식하기
                    </button>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* Quiz Mission */}
          {mission.type === 'quiz' && !isCompleted && (
            <div className="space-y-4">
              {mission.quizOptions?.map((option, index) => (
                <button
                  key={index}
                  onClick={() => !quizSubmitted && setSelectedQuiz(index)}
                  disabled={quizSubmitted}
                  className={`
                    w-full p-4 rounded-[20px] border-[0.75px] text-left transition-all
                    ${quizSubmitted && index === mission.quizAnswer
                      ? 'border-green-500 bg-green-50'
                      : quizSubmitted && index === selectedQuiz
                        ? 'border-red-500 bg-red-50'
                        : selectedQuiz === index
                          ? 'border-emerald-500 bg-emerald-50'
                          : 'border-[#EBEBF0] hover:border-emerald-300'
                    }
                    ${quizSubmitted ? 'cursor-not-allowed' : 'cursor-pointer'}
                  `}
                >
                  <div className="flex items-center gap-3 justify-center ">
                    {/* <div className="w-6 h-6 flex items-center justify-start flex-shrink-0">
                      <Check className={`w-6 h-6 stroke-[3px] ${(quizSubmitted && index === mission.quizAnswer) ||
                        (selectedQuiz === index && !quizSubmitted)
                        ? 'text-[#10B981]'
                        : 'text-[#D1D1D6]'
                        }`} />
                    </div> */}
                    <span className={`
                      font-medium
                      ${quizSubmitted && index === mission.quizAnswer
                        ? 'text-green-700'
                        : quizSubmitted && index === selectedQuiz
                          ? 'text-red-700'
                          : 'text-gray-700'
                      }
                    `}>
                      {option}
                    </span>
                  </div>
                </button>
              ))}

              {!quizSubmitted && (
                <div className="fixed bottom-0 left-0 right-0 p-4 z-50 pointer-events-none" style={{ background: 'linear-gradient(to top, rgba(255,255,255,1) 60%, rgba(255,255,255,0.8) 80%, rgba(255,255,255,0) 100%)' }}>
                  <div className="max-w-md mx-auto  w-full pointer-events-auto">
                    <button
                      onClick={handleQuizSubmit}
                      disabled={selectedQuiz === null}
                      className="w-full bg-[#10B981] text-white font-bold py-[16px] rounded-[16px] shadow-[0_4px_12px_rgba(16,185,129,0.3)] disabled:shadow-none flex items-center justify-center gap-2 hover:-translate-y-1 active:scale-[0.98] transition-transform disabled:opacity-100 disabled:bg-none disabled:bg-[#F4F4F5] disabled:text-[#37383C]/28 disabled:cursor-not-allowed border-[0.75px] border-transparent"
                    >
                      정답 제출
                    </button>
                  </div>
                </div>
              )}

              {/* Removing the intermediate success state entirely */}
              {quizSubmitted && selectedQuiz !== mission.quizAnswer && (
                <div className="bg-red-50 border-[0.75px] border-red-300 rounded-[20px] p-4 text-center">
                  <p className="text-red-700 font-medium">아쉽지만 틀렸습니다. 다시 시도해보세요!</p>
                  <button
                    onClick={() => {
                      setQuizSubmitted(false);
                      setSelectedQuiz(null);
                    }}
                    className="mt-3 text-red-600 font-medium underline"
                  >
                    다시 풀기
                  </button>
                </div>
              )}
            </div>
          )}


        </div>
      </div>
    </div>
  );
}
